O objetivo do trabalho consistiu em recriar a "home page" do site do Governo Federal do Brasil, o GOV.BR, aplicando estrutura semântica, responsividade (mobile-first) e boas práticas de acessibilidade, utilizando apenas HTML e CSS.

Autores: Samuel da Silva Santos, Vinicius Guara e Lucas Melo
